#define BOOST_TEST_MODULE onelib_all
#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
