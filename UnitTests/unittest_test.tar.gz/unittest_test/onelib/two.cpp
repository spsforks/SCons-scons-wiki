#include "two.h"

int two()
{
	return 2;
}
