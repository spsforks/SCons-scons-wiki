#define BOOST_TEST_MODULE two
#include <boost/test/auto_unit_test.hpp>

#include "two.h"

BOOST_AUTO_TEST_CASE(two_test)
{
	BOOST_CHECK_EQUAL(two(), 2);
}
