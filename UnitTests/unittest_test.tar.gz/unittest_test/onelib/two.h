#ifndef TWO_H_INCLUDED
#define TWO_H_INCLUDED

int two();

#endif // TWO_H_INCLUDED
