#include "one.h"

int one()
{
	//return 1;

	// "Bug":
	return 2;
}

int fortytwo()
{
	return 42;
}
