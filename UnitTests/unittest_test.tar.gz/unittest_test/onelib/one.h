#ifndef ONE_H_INCLUDED
#define ONE_H_INCLUDED

int one();
int fortytwo();

#endif // ONE_H_INCLUDED
