#define BOOST_TEST_MODULE one
//#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>

#include "one.h"

BOOST_AUTO_TEST_CASE(one_test)
{
	BOOST_CHECK_EQUAL(one(), 1);
}

BOOST_AUTO_TEST_CASE(fortytwo_test)
{
	BOOST_CHECK_EQUAL(fortytwo(), 42);
}
