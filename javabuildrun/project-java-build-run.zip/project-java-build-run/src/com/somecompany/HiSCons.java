package com.somecompany;

public class HiSCons 
{
	public static void main(String[] args)
	{
		System.out.println("this is an output line, from com.somecompany.HiSCons.java");	
	}	
}
